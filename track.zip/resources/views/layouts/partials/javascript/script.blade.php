<!-- Bootstrap bundle JS -->
<script src="{{ asset('dashboard/assets/js/bootstrap.bundle.min.js') }}"></script>
<!--plugins-->
<script src="{{ asset('dashboard/assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/simplebar/js/simplebar.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/metismenu/js/metisMenu.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/pace.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/chartjs/js/Chart.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/chartjs/js/Chart.extension.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/apexcharts-bundle/js/apexcharts.min.js') }}"></script>
<!--app-->
<script src="{{ asset('dashboard/assets/js/app.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/index3.js') }}"></script>

<script src="{{ asset('dashboard/assets/plugins/select2/js/select2.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/form-select2.js') }}"></script>

{{-- <script src="{{ asset('dashboard/assets/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/table-datatable.js') }}"></script> --}}

<script>
    new PerfectScrollbar(".best-product")
</script>
